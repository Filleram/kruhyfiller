﻿
namespace kruhyfiller
{
    partial class Form1
    {
        /// <summary>
        /// Vyžaduje se proměnná návrháře.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Uvolněte všechny používané prostředky.
        /// </summary>
        /// <param name="disposing">hodnota true, když by se měl spravovaný prostředek odstranit; jinak false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Kód generovaný Návrhářem Windows Form

        /// <summary>
        /// Metoda vyžadovaná pro podporu Návrháře - neupravovat
        /// obsah této metody v editoru kódu.
        /// </summary>
        private void InitializeComponent()
        {
            this.pboxColor1 = new System.Windows.Forms.PictureBox();
            this.pboxColor2 = new System.Windows.Forms.PictureBox();
            this.pboxColor3 = new System.Windows.Forms.PictureBox();
            this.pboxColor4 = new System.Windows.Forms.PictureBox();
            this.pboxColor5 = new System.Windows.Forms.PictureBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.YUpDown = new System.Windows.Forms.NumericUpDown();
            this.XUpDown = new System.Windows.Forms.NumericUpDown();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.nmrVelikost = new System.Windows.Forms.NumericUpDown();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.colorDialog1 = new System.Windows.Forms.ColorDialog();
            ((System.ComponentModel.ISupportInitialize)(this.pboxColor1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pboxColor2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pboxColor3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pboxColor4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pboxColor5)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.YUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.XUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nmrVelikost)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            this.SuspendLayout();
            // 
            // pboxColor1
            // 
            this.pboxColor1.BackColor = System.Drawing.Color.Aqua;
            this.pboxColor1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pboxColor1.Location = new System.Drawing.Point(80, 24);
            this.pboxColor1.Name = "pboxColor1";
            this.pboxColor1.Size = new System.Drawing.Size(25, 24);
            this.pboxColor1.TabIndex = 0;
            this.pboxColor1.TabStop = false;
            this.pboxColor1.Click += new System.EventHandler(this.pboxColor1_Click);
            // 
            // pboxColor2
            // 
            this.pboxColor2.BackColor = System.Drawing.Color.Lime;
            this.pboxColor2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pboxColor2.Location = new System.Drawing.Point(142, 24);
            this.pboxColor2.Name = "pboxColor2";
            this.pboxColor2.Size = new System.Drawing.Size(25, 24);
            this.pboxColor2.TabIndex = 1;
            this.pboxColor2.TabStop = false;
            this.pboxColor2.Click += new System.EventHandler(this.pboxColor2_Click);
            // 
            // pboxColor3
            // 
            this.pboxColor3.BackColor = System.Drawing.Color.Red;
            this.pboxColor3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pboxColor3.Location = new System.Drawing.Point(111, 24);
            this.pboxColor3.Name = "pboxColor3";
            this.pboxColor3.Size = new System.Drawing.Size(25, 24);
            this.pboxColor3.TabIndex = 2;
            this.pboxColor3.TabStop = false;
            this.pboxColor3.Click += new System.EventHandler(this.pboxColor3_Click);
            // 
            // pboxColor4
            // 
            this.pboxColor4.BackColor = System.Drawing.Color.Yellow;
            this.pboxColor4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pboxColor4.Location = new System.Drawing.Point(173, 24);
            this.pboxColor4.Name = "pboxColor4";
            this.pboxColor4.Size = new System.Drawing.Size(25, 24);
            this.pboxColor4.TabIndex = 3;
            this.pboxColor4.TabStop = false;
            this.pboxColor4.Click += new System.EventHandler(this.pboxColor4_Click);
            // 
            // pboxColor5
            // 
            this.pboxColor5.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.pboxColor5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pboxColor5.Location = new System.Drawing.Point(204, 24);
            this.pboxColor5.Name = "pboxColor5";
            this.pboxColor5.Size = new System.Drawing.Size(25, 24);
            this.pboxColor5.TabIndex = 4;
            this.pboxColor5.TabStop = false;
            this.pboxColor5.Click += new System.EventHandler(this.pboxColor5_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ControlLight;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.YUpDown);
            this.panel1.Controls.Add(this.XUpDown);
            this.panel1.Controls.Add(this.checkBox1);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.nmrVelikost);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Location = new System.Drawing.Point(251, 2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(537, 75);
            this.panel1.TabIndex = 5;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(415, 40);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(20, 13);
            this.label8.TabIndex = 9;
            this.label8.Text = "Y=";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(415, 15);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(20, 13);
            this.label7.TabIndex = 8;
            this.label7.Text = "X=";
            // 
            // YUpDown
            // 
            this.YUpDown.Location = new System.Drawing.Point(441, 38);
            this.YUpDown.Name = "YUpDown";
            this.YUpDown.Size = new System.Drawing.Size(60, 20);
            this.YUpDown.TabIndex = 7;
            // 
            // XUpDown
            // 
            this.XUpDown.Location = new System.Drawing.Point(441, 13);
            this.XUpDown.Name = "XUpDown";
            this.XUpDown.Size = new System.Drawing.Size(62, 20);
            this.XUpDown.TabIndex = 6;
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Location = new System.Drawing.Point(278, 25);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(68, 17);
            this.checkBox1.TabIndex = 5;
            this.checkBox1.Text = "náhodná";
            this.checkBox1.UseVisualStyleBackColor = true;
            this.checkBox1.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(226, 40);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(46, 13);
            this.label6.TabIndex = 4;
            this.label6.Text = "KRUHŮ";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(226, 17);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(46, 13);
            this.label5.TabIndex = 3;
            this.label5.Text = "POZICE";
            // 
            // nmrVelikost
            // 
            this.nmrVelikost.Location = new System.Drawing.Point(96, 24);
            this.nmrVelikost.Name = "nmrVelikost";
            this.nmrVelikost.Size = new System.Drawing.Size(87, 20);
            this.nmrVelikost.TabIndex = 2;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(38, 40);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(52, 13);
            this.label4.TabIndex = 1;
            this.label4.Text = "KRUHŮ  ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(31, 17);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(59, 13);
            this.label3.TabIndex = 0;
            this.label3.Text = "VELIKOST";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.ControlLight;
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.label2);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Controls.Add(this.pboxColor1);
            this.panel2.Controls.Add(this.pboxColor2);
            this.panel2.Controls.Add(this.pboxColor5);
            this.panel2.Controls.Add(this.pboxColor3);
            this.panel2.Controls.Add(this.pboxColor4);
            this.panel2.Location = new System.Drawing.Point(12, 2);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(233, 75);
            this.panel2.TabIndex = 6;
            this.panel2.Paint += new System.Windows.Forms.PaintEventHandler(this.panel2_Paint);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(15, 40);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(46, 13);
            this.label2.TabIndex = 6;
            this.label2.Text = "KRUHŮ";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(15, 17);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(43, 13);
            this.label1.TabIndex = 5;
            this.label1.Text = "BARVA";
            // 
            // pictureBox6
            // 
            this.pictureBox6.Location = new System.Drawing.Point(12, 83);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(776, 355);
            this.pictureBox6.TabIndex = 7;
            this.pictureBox6.TabStop = false;
            this.pictureBox6.Click += new System.EventHandler(this.pictureBox6_Click);
            this.pictureBox6.Paint += new System.Windows.Forms.PaintEventHandler(this.pictureBox6_Paint);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.pictureBox6);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.pboxColor1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pboxColor2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pboxColor3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pboxColor4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pboxColor5)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.YUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.XUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nmrVelikost)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox pboxColor1;
        private System.Windows.Forms.PictureBox pboxColor2;
        private System.Windows.Forms.PictureBox pboxColor3;
        private System.Windows.Forms.PictureBox pboxColor4;
        private System.Windows.Forms.PictureBox pboxColor5;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.NumericUpDown YUpDown;
        private System.Windows.Forms.NumericUpDown XUpDown;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.NumericUpDown nmrVelikost;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.ColorDialog colorDialog1;
    }
}

